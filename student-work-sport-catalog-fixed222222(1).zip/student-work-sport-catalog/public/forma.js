const CATS={protein:['Протеин','🥛',85],gainer:['Гейнеры','💪',30],creatine:['Креатин','⚡',70],amino:['Аминокислоты','🧬',200],vitamins:['Витамины и минералы','💊',140],pre:['Предтренировочные','🔥',20],electro:['Электролиты','💧',190],bars:['Батончики','🍫',40],acc:['Аксессуары','🏋️',260]};
const R=[ // cat,name,brand,price,old,rating,rev,stock,form,mass,serv,flavor,protein
['protein','Whey Isolate 900 g','Volt Nutrition',3990,4790,4.8,412,30,'Порошок','900 г',30,'Шоколад',27],
['protein','Whey Classic 2 kg','IronLeaf',4990,0,4.6,880,12,'Порошок','2000 г',66,'Ваниль',24],
['protein','Casein Night 900 g','Kinetic Lab',4290,4990,4.5,190,8,'Порошок','900 г',30,'Печенье',25],
['protein','Plant Protein 750 g','IronLeaf',3490,0,4.3,210,25,'Порошок','750 г',25,'Клубника',22],
['protein','Whey Hydro 1.2 kg','Apex Fuel',6290,7290,4.7,156,0,'Порошок','1200 г',40,'Без вкуса',28],
['protein','Whey Blend 1 kg','NordForm',2990,3490,4.4,530,40,'Порошок','1000 г',33,'Банан',23],
['gainer','Mass Gainer 3 kg','Apex Fuel',3790,4490,4.4,340,20,'Порошок','3000 г',20,'Шоколад',22],
['gainer','Mass Pro 4.5 kg','NordForm',5290,0,4.5,120,14,'Порошок','4500 г',30,'Ваниль',20],
['gainer','Lean Gainer 1.5 kg','Volt Nutrition',2890,3290,4.2,95,0,'Порошок','1500 г',15,'Клубника',25],
['creatine','Creatine Monohydrate 300 g','Volt Nutrition',1290,0,4.9,1200,80,'Порошок','300 г',60,'Без вкуса',0],
['creatine','Creatine Pure 500 g','Kinetic Lab',1990,2390,4.8,640,35,'Порошок','500 г',100,'Без вкуса',0],
['creatine','Creatine Sport 250 g','NordForm',990,1190,4.5,310,50,'Порошок','250 г',50,'Лимон',0],
['creatine','Creatine Caps 120','IronLeaf',1490,0,4.4,170,22,'Капсулы','120 капс.',40,'Без вкуса',0],
['amino','BCAA 2:1:1 300 g','Apex Fuel',1690,1990,4.5,420,30,'Порошок','300 г',30,'Арбуз',0],
['amino','EAA Complex 400 g','Kinetic Lab',2290,0,4.6,260,18,'Порошок','400 г',40,'Манго',0],
['amino','Glutamine 500 g','Volt Nutrition',1890,2190,4.4,180,0,'Порошок','500 г',100,'Без вкуса',0],
['amino','BCAA Tabs 200','NordForm',1390,0,4.2,90,28,'Таблетки','200 табл.',50,'Без вкуса',0],
['vitamins','Multivitamin Daily 90','IronLeaf',1190,1490,4.6,520,60,'Таблетки','90 табл.',90,'Без вкуса',0],
['vitamins','Omega-3 120 caps','Kinetic Lab',1590,0,4.7,390,45,'Капсулы','120 капс.',60,'Без вкуса',0],
['vitamins','Magnesium B6 60','NordForm',790,990,4.5,240,70,'Капсулы','60 капс.',30,'Без вкуса',0],
['vitamins','Vitamin D3 2000 90','Volt Nutrition',690,0,4.6,300,0,'Капсулы','90 капс.',90,'Без вкуса',0],
['pre','Pre-Workout Blast 300 g','Apex Fuel',2190,2590,4.3,280,26,'Порошок','300 г',30,'Кола',0],
['pre','Pre Focus 240 g','Kinetic Lab',1990,0,4.4,140,15,'Порошок','240 г',30,'Лимон',0],
['pre','Pre Stim-Free 360 g','NordForm',2390,2790,4.2,85,9,'Порошок','360 г',30,'Арбуз',0],
['electro','Electrolyte Mix 300 g','Volt Nutrition',1190,0,4.5,200,55,'Порошок','300 г',30,'Лимон',0],
['electro','Hydro Tabs 20','IronLeaf',590,690,4.3,130,80,'Таблетки','20 табл.',20,'Апельсин',0],
['bars','Protein Bar Box 12','Kinetic Lab',1490,1790,4.4,360,40,'Батончик','12×60 г',12,'Печенье',20],
['bars','Crunch Bar 10','NordForm',1190,0,4.1,120,0,'Батончик','10×50 г',10,'Шоколад',15],
['acc','Shaker 700 ml','Apex Fuel',490,0,4.6,900,100,'Аксессуар','700 мл',1,'—',0],
['acc','Lifting Straps','IronLeaf',690,890,4.5,150,35,'Аксессуар','1 пара',1,'—',0],
['acc','Steel Shaker 600 ml','Volt Nutrition',790,0,4.7,85,42,'Аксессуар','600 мл',1,'—',0]];
const DEF=R.map((r,i)=>({id:i+1,hid:0,imgs:[],cat:r[0],name:r[1],brand:r[2],price:r[3],old:r[4],disc:r[4]?Math.round(100-r[3]/r[4]*100):0,rating:r[5],rev:r[6],stock:r[7],form:r[8],mass:r[9],serv:r[10],flavor:r[11],protein:r[12],hue:CATS[r[0]][2],emoji:CATS[r[0]][1],
desc:`${r[1]} от бренда ${r[2]} — продукт категории «${CATS[r[0]][0]}» для регулярных тренировок. Удобная упаковка ${r[9]}, ${r[10]} порций. Информация носит справочный характер.`}));
// ---- каталог можно редактировать: изменения хранятся в localStorage браузера (ключ fm_products)
let P;try{const sp=JSON.parse(localStorage.getItem('fm_products'));P=Array.isArray(sp)&&sp.length?sp:JSON.parse(JSON.stringify(DEF))}catch(e){P=JSON.parse(JSON.stringify(DEF))}
const vis=()=>P.filter(p=>!p.hid);
function saveP(){try{localStorage.setItem('fm_products',JSON.stringify(P));return true}catch(e){toast('Не хватило места в браузере — загрузите изображения поменьше',1);return false}}
let BR,FORMS,FLAV;const lists=()=>{const v=vis();BR=[...new Set(v.map(p=>p.brand))];FORMS=[...new Set(v.map(p=>p.form))];FLAV=[...new Set(v.map(p=>p.flavor))].filter(x=>x!=='—')};lists();
const $=s=>document.querySelector(s),rub=n=>n.toLocaleString('ru-RU')+' ₽',esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem('fm_'+k))??d}catch(e){return d}},SV=(k,v)=>{try{localStorage.setItem('fm_'+k,JSON.stringify(v))}catch(e){}};
let S={cart:LS('cart',{}),fav:LS('fav',[]),cmp:LS('cmp',[]),users:LS('users',[{name:'Демо Пользователь',email:'demo@forma.test',phone:'+7 900 000-00-00',pass:'demo123',orders:[],notif:true}]),me:LS('me',null),theme:LS('theme','auto'),promo:LS('promo','')};
const save=()=>{['cart','fav','cmp','users','me','theme','promo'].forEach(k=>SV(k,S[k]))};
const user=()=>S.users.find(u=>u.email===S.me);
const gp=id=>P.find(p=>p.id==id&&!p.hid),ga=id=>P.find(p=>p.id==id);
const purge=()=>{const ok=new Set(vis().map(p=>p.id));S.fav=S.fav.filter(i=>ok.has(i));S.cmp=S.cmp.filter(i=>ok.has(i));Object.keys(S.cart).forEach(k=>{const p=gp(k);if(!p||!p.stock)delete S.cart[k];else S.cart[k]=Math.min(S.cart[k],p.stock)})};
const stars=r=>`<span class="rt"><b>★</b> ${r.toFixed(1)}</span>`;
const pic=(p,i=0,x='')=>{const im=p.imgs&&p.imgs.length?(p.imgs[i]||p.imgs[0]):'',lb=`role="img" aria-label="${esc(p.name)}, фото ${i+1}"`;return im?`<div class="th"${x?` style="${x}"`:''} ${lb}><img src="${esc(im)}" alt="" loading="lazy"></div>`:`<div class="th" style="background:linear-gradient(${135+i*50}deg,hsl(${p.hue+i*25} 70% 88%),hsl(${p.hue+i*25} 60% 72%));${x}" ${lb}>${p.emoji}</div>`};
const thumbsIdx=p=>p.imgs&&p.imgs.length?(p.imgs.length>1?p.imgs.map((_,i)=>i):[]):[0,1,2];
function toast(m,er){const t=document.createElement('div');t.className='ts'+(er?' er':'');t.textContent=m;$('#toasts').append(t);setTimeout(()=>t.remove(),2200)}
function badges(){$('#bf').textContent=S.fav.length;$('#bc').textContent=S.cmp.length;$('#bk').textContent=Object.values(S.cart).reduce((a,b)=>a+b,0);$('#bu').title=S.me?user().name:'Войти';
const t=S.theme;if(t==='auto')document.documentElement.removeAttribute('data-theme');else document.documentElement.dataset.theme=t}
const cbtn=(p,c,l='В корзину',x='')=>S.cart[p.id]?`<a class="btn ${c} in" href="#/cart" title="Перейти в корзину">В корзине ✓</a>`:`<button class="btn ${c}" data-act="cart" data-id="${p.id}" ${x}>${l}</button>`;
const PQ={};
const cardBuy=p=>{const inC=S.cart[p.id]||0,n=inC||PQ[p.id]||1;return`<div class="cb">${cbtn(p,'p sm','В корзину','data-cq="1"')}${inC?`<button class="btn sm rmb" data-act="crm" data-id="${p.id}" title="Удалить из корзины" aria-label="Удалить из корзины">🗑</button>`:''}<input class="cq" type="number" min="1" max="${p.stock}" value="${n}" data-id="${p.id}" title="Количество" aria-label="Количество"></div>`};
const card=p=>`<article class="card"><a href="#/product/${p.id}">${pic(p)}</a>${p.disc?`<span class="tag">−${p.disc}%</span>`:''}
<div class="ab"><button data-act="fav" data-id="${p.id}" class="${S.fav.includes(p.id)?'on':''}" aria-label="В избранное" title="В избранное">${S.fav.includes(p.id)?'♥':'♡'}</button><button data-act="cmp" data-id="${p.id}" class="${S.cmp.includes(p.id)?'on':''}" aria-label="Сравнить" title="Сравнить">⇄</button></div>
<div class="br">${p.brand}</div><a class="nm" href="#/product/${p.id}">${p.name}</a><div>${stars(p.rating)} <span class="rt">(${p.rev})</span></div>
<div><span class="pr">${rub(p.price)}</span>${p.old?`<span class="old">${rub(p.old)}</span>`:''}</div>
${p.stock?cardBuy(p):`<span class="out">Нет в наличии</span><button class="btn sm" disabled>Закончился</button>`}</article>`;
const empty=(e,t,s,l='#/catalog',b='Перейти в каталог')=>`<div class="emp"><div class="e">${e}</div><h2>${t}</h2><p class="rt">${s}</p><a class="btn p" href="${l}">${b}</a></div>`;
// filters
const F0=()=>({q:'',cats:[],brands:[],forms:[],flav:[],min:0,max:10000,rating:0,stock:false,disc:false,prot:0,sort:'pop'});let f=F0();
const sorts={pop:(a,b)=>b.rev-a.rev,rate:(a,b)=>b.rating-a.rating||b.rev-a.rev,asc:(a,b)=>a.price-b.price,desc:(a,b)=>b.price-a.price,disc:(a,b)=>b.disc-a.disc,new:(a,b)=>b.id-a.id};
const has=(a,v)=>!a.length||a.includes(v);
const filt=()=>{const q=f.q.trim().toLowerCase();return vis().filter(p=>(!q||(p.name+' '+p.brand+' '+CATS[p.cat][0]).toLowerCase().includes(q))&&has(f.cats,p.cat)&&has(f.brands,p.brand)&&has(f.forms,p.form)&&has(f.flav,p.flavor)&&p.price>=f.min&&p.price<=f.max&&p.rating>=f.rating&&(!f.stock||p.stock>0)&&(!f.disc||p.disc>0)&&(!f.prot||p.protein>=f.prot)).sort(sorts[f.sort])};
const chk=(n,v,l,a)=>`<label><input type="checkbox" data-f="${n}" value="${v}" ${a.includes(v)?'checked':''}>${l}</label>`;
const panel=()=>`<button class="btn sm mob" data-act="fclose" style="margin-bottom:8px">✕ Закрыть</button><h3>Фильтры</h3>
<h4>Категория</h4>${Object.entries(CATS).map(([k,v])=>chk('cats',k,v[0],f.cats)).join('')}
<h4>Цена, ₽</h4><div style="display:flex;justify-content:space-between"><input type="number" data-f="min" value="${f.min}" min="0" aria-label="Мин"><input type="number" data-f="max" value="${f.max}" aria-label="Макс"></div><input type="range" data-f="rng" min="0" max="10000" step="100" value="${f.max}" style="width:100%">
<h4>Бренд</h4>${BR.map(b=>chk('brands',b,b,f.brands)).join('')}
<h4>Рейтинг</h4><select data-f="rating">${[[0,'Любой'],[4,'4.0 и выше'],[4.5,'4.5 и выше']].map(([v,l])=>`<option value="${v}" ${f.rating==v?'selected':''}>${l}</option>`).join('')}</select>
<h4>Форма</h4>${FORMS.map(b=>chk('forms',b,b,f.forms)).join('')}
<h4>Вкус</h4>${FLAV.map(b=>chk('flav',b,b,f.flav)).join('')}
<h4>Белок на порцию</h4><select data-f="prot">${[[0,'Любой'],[20,'от 20 г'],[25,'от 25 г']].map(([v,l])=>`<option value="${v}" ${f.prot==v?'selected':''}>${l}</option>`).join('')}</select>
<h4>Прочее</h4><label><input type="checkbox" data-f="stock" ${f.stock?'checked':''}>Только в наличии</label><label><input type="checkbox" data-f="disc" ${f.disc?'checked':''}>Со скидкой</label>
<button class="btn" data-act="reset" style="width:100%;margin-top:14px">Сбросить фильтры</button><button class="btn p mob" data-act="fclose" style="width:100%;margin-top:8px">Показать товары</button>`;
function readF(){const p=$('#fp');if(!p)return;['cats','brands','forms','flav'].forEach(n=>f[n]=[...p.querySelectorAll(`[data-f=${n}]:checked`)].map(i=>i.value));
f.min=+p.querySelector('[data-f=min]').value||0;f.max=+p.querySelector('[data-f=max]').value||10000;f.rating=+p.querySelector('[data-f=rating]').value;f.prot=+p.querySelector('[data-f=prot]').value;f.stock=p.querySelector('[data-f=stock]').checked;f.disc=p.querySelector('[data-f=disc]').checked}
function grid(){const g=$('#grid');if(!g)return;const l=filt();$('#cnt').textContent=`Найдено товаров: ${l.length}`;
g.innerHTML=l.length?`<div class="g g4">${l.map(card).join('')}</div>`:empty('🔍','Ничего не найдено','Измените запрос или сбросьте фильтры','#/catalog','Сбросить').replace('href="#/catalog"','href="#/catalog" data-act="reset"')}
// views
const V={};
V.home=()=>{const top=[...vis()].sort(sorts.pop).slice(0,8);return`<section class="hero"><div><h1>Питание для тренировок без лишнего шума</h1><p>Каталог спортивного питания и аксессуаров: удобный поиск, подробные характеристики, сравнение и быстрая корзина.</p><a class="btn p" href="#/catalog" style="margin-top:14px">Перейти в каталог</a></div><div class="v" aria-hidden="true">🏋️</div></section>
<h2 class="s">Категории</h2><div class="g g3">${['protein','creatine','gainer','vitamins','pre','electro'].map(k=>`<a class="cat" href="#/catalog?cat=${k}"><span>${CATS[k][1]}</span>${CATS[k][0]}</a>`).join('')}</div>
<h2 class="s">Популярные товары</h2><div class="g g4">${top.map(card).join('')}</div>
<h2 class="s">Почему FORMA</h2><div class="adv"><div><h3>🔎 Удобный поиск</h3><p class="rt">Подсказки по названию, бренду и категории.</p></div><div><h3>📋 Характеристики</h3><p class="rt">Таблицы с составом и параметрами.</p></div><div><h3>⇄ Сравнение</h3><p class="rt">Сопоставляйте товары одной категории.</p></div><div><h3>♡ Избранное</h3><p class="rt">Сохраняется после перезагрузки.</p></div><div><h3>🛒 Удобная корзина</h3><p class="rt">Промокод и автопересчёт суммы.</p></div></div>
<h2 class="s">Быстрый переход</h2><div style="display:flex;gap:8px;flex-wrap:wrap">${Object.entries(CATS).map(([k,v])=>`<a class="btn sm" href="#/catalog?cat=${k}">${v[0]}</a>`).join('')}</div>`};
V.catalog=q=>{if(q.has('cat')||q.has('q')){f=F0();if(q.get('cat'))f.cats=[q.get('cat')];if(q.get('q'))f.q=q.get('q')}
const c=f.cats.length===1?CATS[f.cats[0]][0]:'Каталог';document.title=c+' — FORMA';
return`<div class="cl"><aside class="fp" id="fp">${panel()}</aside><section><h1>${c}</h1><p class="rt" id="cnt"></p><div class="tb"><input id="cq" placeholder="Поиск по каталогу" value="${esc(f.q)}" aria-label="Поиск"><select id="so" aria-label="Сортировка">${[['pop','По популярности'],['rate','По рейтингу'],['asc','Сначала дешевле'],['desc','Сначала дороже'],['disc','По размеру скидки'],['new','По новизне']].map(([v,l])=>`<option value="${v}" ${f.sort===v?'selected':''}>${l}</option>`).join('')}</select><button class="btn fbtn" data-act="fopen">⚙ Фильтры</button></div><div id="grid"><div class="g g4">${'<div class="sk"></div>'.repeat(4)}</div></div></section></div>`};
V.after_catalog=()=>{setTimeout(grid,350)};
V.product=id=>{const p=gp(id);if(!p)return empty('⚠️','Товар не найден','Возможно, ссылка устарела')
document.title=p.name+' — FORMA';const inC=S.cart[p.id]||0;const rvs=[['Алексей','Хорошее качество, упаковка целая, вкус приятный.'],['Марина','Удобно растворяется, беру не первый раз.'],['Игорь','Цена адекватная, доставка быстрая.']].map((r,i)=>({n:r[0],t:r[1],s:Math.max(3,Math.round(p.rating-i*.4)),d:`${10+i*5}.0${(p.id%8)+1}.2026`}));
const sp=[['Бренд',p.brand],['Категория',CATS[p.cat][0]],['Форма',p.form],['Масса',p.mass],['Порций',p.serv],['Вкус',p.flavor]];
return`<nav class="rt" style="margin-top:14px"><a href="#/">Главная</a> / <a href="#/catalog?cat=${p.cat}">${CATS[p.cat][0]}</a> / ${p.name}</nav><div class="pd"><div><div id="gal">${pic(p,0)}</div><div class="thumbs">${thumbsIdx(p).map(i=>`<div data-act="thumb" data-id="${p.id}" data-i="${i}" class="${i?'':'on'}">${pic(p,i)}</div>`).join('')}</div></div>
<div><div class="br">${p.brand}</div><h1>${p.name}</h1><p>${stars(p.rating)} <span class="rt">· ${p.rev} отзывов</span></p><p><span class="pr" style="font-size:30px">${rub(p.price)}</span>${p.old?`<span class="old">${rub(p.old)}</span> <span class="tag" style="position:static">−${p.disc}%</span>`:''}</p>
<p>${p.stock?`<b style="color:#2a9d4a">В наличии</b> <span class="rt">(${p.stock} шт.)</span>`:'<b class="out">Нет в наличии</b>'}</p><p>${p.desc}</p>
<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center"><div class="qty"><button data-act="pq" data-d="-1">−</button><span id="pq">1</span><button data-act="pq" data-d="1">+</button></div>
${cbtn(p,'p','Добавить в корзину','data-q="1" '+(p.stock?'':'disabled'))}<button class="btn d" data-act="buy" data-id="${p.id}" ${p.stock?'':'disabled'}>Купить сейчас</button></div>
<div style="display:flex;gap:10px;margin-top:10px"><button class="btn" data-act="fav" data-id="${p.id}">${S.fav.includes(p.id)?'♥ В избранном':'♡ В избранное'}</button><button class="btn" data-act="cmp" data-id="${p.id}">${S.cmp.includes(p.id)?'⇄ В сравнении':'⇄ Сравнить'}</button></div><p style="margin-top:10px"><a class="btn sm" href="#/admin/edit/${p.id}">✎ Редактировать товар</a></p>${inC?`<p class="rt">В корзине: ${inC} шт.</p>`:''}</div></div>
<h2 class="s">Описание</h2><p>${p.desc} Подходит для использования в рамках обычного рациона. Храните в сухом прохладном месте.</p>
<h2 class="s">Характеристики</h2><div class="ov"><table>${sp.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('')}</table></div>
<h2 class="s">Состав</h2><div class="ov"><table><tr><td>Порция</td><td>${p.mass.includes('×')?p.mass.split('×')[1]:(parseInt(p.mass)?'≈ '+Math.round(parseInt(p.mass)/p.serv)+' г':'—')}</td></tr><tr><td>Белок</td><td>${p.protein?p.protein+' г':'—'}</td></tr><tr><td>Основной компонент</td><td>${p.name.split(' ')[0]}</td></tr><tr><td>Ароматизатор</td><td>${p.flavor==='Без вкуса'||p.flavor==='—'?'нет':'натуральный/идентичный натуральному'}</td></tr></table></div>
<h2 class="s">Отзывы</h2><p>${stars(p.rating)} · ${p.rev} отзывов</p>${rvs.map(r=>`<div class="rv"><b>${r.n}</b> <span class="rt">· ${'★'.repeat(r.s)} · ${r.d}</span><p style="margin:4px 0 0">${r.t}</p></div>`).join('')}`};
V.favorites=()=>{const l=S.fav.map(gp).filter(Boolean);return`<h1 style="margin-top:20px">Избранное</h1>`+(l.length?`<div class="g g4" style="margin-top:14px">${l.map(card).join('')}</div>`:empty('♡','В избранном пока пусто','Нажимайте на сердечко у товаров'))};
V.compare=()=>{const l=S.cmp.map(gp).filter(Boolean);if(!l.length)return`<h1 style="margin-top:20px">Сравнение</h1>`+empty('⇄','Нечего сравнивать','Добавьте 2–4 товара одной категории');
const rows=[['Цена',p=>rub(p.price)],['Бренд',p=>p.brand],['Масса',p=>p.mass],['Порций',p=>p.serv],['Белок на порцию',p=>p.protein?p.protein+' г':'—'],['Вкус',p=>p.flavor],['Форма',p=>p.form],['Рейтинг',p=>'★ '+p.rating.toFixed(1)]];
return`<div style="display:flex;justify-content:space-between;align-items:center;margin-top:20px"><h1>Сравнение · ${CATS[l[0].cat][0]}</h1><button class="btn sm" data-act="clrcmp">Очистить</button></div><div class="ov" style="margin-top:14px"><table><tr><th></th>${l.map(p=>`<th>${pic(p,0,'max-width:90px;font-size:36px;margin-bottom:6px')}<a href="#/product/${p.id}">${p.name}</a><br>${cbtn(p,'sm','В корзину',p.stock?'':'disabled')} <button class="btn sm" data-act="cmp" data-id="${p.id}">✕</button></th>`).join('')}</tr>
${rows.map(([n,fn])=>{const v=l.map(fn),d=new Set(v).size>1&&l.length>1;return`<tr><td>${n}</td>${v.map(x=>`<td class="${d?'df':''}">${x}</td>`).join('')}</tr>`}).join('')}</table></div><p class="rt">Отличающиеся значения подсвечены.</p>`};
const calc=()=>{const it=Object.entries(S.cart).map(([i,q])=>({p:gp(i),q})).filter(x=>x.p);const sum=it.reduce((a,x)=>a+x.p.price*x.q,0),old=it.reduce((a,x)=>a+(x.p.old||x.p.price)*x.q,0),pd=S.promo==='FIT10'?Math.round(sum*.1):0;return{it,sum,dis:old-sum+pd,pd,tot:sum-pd,ship:sum>5000||!sum?0:350}};
V.cart=()=>{const c=calc();if(!c.it.length)return`<h1 style="margin-top:20px">Корзина</h1>`+empty('🛒','Корзина пока пуста','Добавьте что-нибудь из каталога');
return`<h1 style="margin:20px 0 14px">Корзина</h1><div class="cg"><div>${c.it.map(({p,q})=>`<div class="ci"><a href="#/product/${p.id}">${pic(p)}</a><div><a href="#/product/${p.id}"><b>${p.name}</b></a><div class="rt">${p.brand} · ${rub(p.price)}</div><div class="qty" style="margin-top:6px"><button data-act="dec" data-id="${p.id}">−</button><span>${q}</span><button data-act="inc" data-id="${p.id}">+</button></div></div><div style="text-align:right"><b>${rub(p.price*q)}</b><br><button class="btn sm" data-act="rm" data-id="${p.id}">Удалить</button></div></div>`).join('')}</div>
<aside class="sm2"><h3>Ваш заказ</h3><div class="r"><span>Товары</span><span>${rub(c.sum)}</span></div><div class="r"><span>Скидка</span><span>−${rub(c.dis)}</span></div><div class="r"><span>Доставка</span><span>${c.ship?rub(c.ship):'Бесплатно'}</span></div><div class="r"><b>Итого</b><b>${rub(c.tot+c.ship)}</b></div>
<div style="display:flex;gap:6px;margin:10px 0"><input id="pc" placeholder="Промокод (FIT10)" value="${esc(S.promo)}" style="flex:1;padding:9px;border-radius:10px;border:1px solid var(--bd);background:var(--bg)"><button class="btn sm" data-act="promo">OK</button></div><a class="btn p" href="#/checkout" style="width:100%">Оформить заказ</a></aside></div>`};
const fi=(l,n,t='text',v='',x='')=>`<label>${l}<input name="${n}" type="${t}" value="${esc(v)}" ${x}></label>`;
V.checkout=()=>{const c=calc();if(!c.it.length)return V.cart();const u=user()||{};return`<form class="fm" id="co"><h1>Оформление заказа</h1>${fi('Имя','name','text',u.name,'required')}${fi('Телефон','phone','tel',u.phone,'required')}${fi('Email','email','email',u.email,'required')}${fi('Адрес','addr','text','','required')}
<label>Доставка<select name="ship"><option>Курьер</option><option>Пункт выдачи</option><option>Самовывоз</option></select></label><label>Оплата (демо)<select name="pay"><option>Картой онлайн (демо)</option><option>При получении</option></select></label>
<div class="r" style="display:flex;justify-content:space-between"><b>К оплате</b><b>${rub(c.tot+c.ship)}</b></div><button class="btn p">Подтвердить заказ</button></form>`};
const STS=['Новый','Подтвержден','Собирается','Отправлен','Доставлен'];
const stat=o=>STS[Math.min(4,Math.floor((Date.now()-o.ts)/20000)+o.s0)];
V.success=id=>{const o=user()?.orders.find(o=>o.id==id);if(!o)return empty('⚠️','Заказ не найден','','#/account?tab=orders','К заказам');return`<div class="fm" style="text-align:center"><div style="font-size:54px">✅</div><h1>Заказ успешно оформлен</h1><p>Номер: <b>${o.id}</b> · ${new Date(o.ts).toLocaleDateString('ru-RU')} · <span class="st">${stat(o)}</span></p><div style="text-align:left">${o.items.map(i=>`<div style="display:flex;justify-content:space-between"><span>${i.n} × ${i.q}</span><span>${rub(i.p*i.q)}</span></div>`).join('')}</div><h3>Итого: ${rub(o.total)}</h3><a class="btn p" href="#/account?tab=orders">Мои заказы</a></div>`};
V.account=q=>{const u=user(),t=q.get('tab')||'profile';const T=[['profile','Профиль'],['orders','Мои заказы'],['settings','Настройки']];let b='';
if(t==='profile')b=`<form class="fm" id="pf" style="margin:0">${fi('Имя','name','text',u.name)}${fi('Email','email','email',u.email,'disabled')}${fi('Телефон','phone','tel',u.phone)}<button class="btn p">Сохранить</button></form>`;
if(t==='orders')b=u.orders.length?`<div class="ov"><table><tr><th>№</th><th>Дата</th><th>Сумма</th><th>Статус</th></tr>${u.orders.map(o=>`<tr><td><a href="#/success/${o.id}">${o.id}</a></td><td>${new Date(o.ts).toLocaleDateString('ru-RU')}</td><td>${rub(o.total)}</td><td><span class="st">${stat(o)}</span></td></tr>`).join('')}</table></div>`:empty('📦','Заказов пока нет','Оформите первый тестовый заказ');
if(t==='settings')b=`<form class="fm" id="sf" style="margin:0"><label><span><input type="checkbox" name="notif" style="width:auto" ${u.notif?'checked':''}> Уведомления о заказах</span></label><label>Тема<select name="theme">${[['auto','Системная'],['light','Светлая'],['dark','Тёмная']].map(([v,l])=>`<option value="${v}" ${S.theme===v?'selected':''}>${l}</option>`).join('')}</select></label><button class="btn p">Сохранить</button></form>`;
return`<div class="ac2"><nav>${T.map(([k,l])=>`<a class="${t===k?'on':''}" href="#/account?tab=${k}">${l}</a>`).join('')}<a href="#/favorites">Избранное (${S.fav.length})</a><a href="#/compare">Сравнение (${S.cmp.length})</a><a href="#/" data-act="logout">Выйти</a></nav><section><h1 style="margin-bottom:14px">Личный кабинет</h1>${b}</section></div>`};
V.login=()=>`<form class="fm" id="lg"><h1>Вход</h1>${fi('Email','email','email','demo@forma.test','required')}${fi('Пароль','pass','password','demo123','required')}<button class="btn p">Войти</button><p class="rt"><a href="#/register">Регистрация</a> · <a href="#/forgot-password">Забыли пароль?</a><br>Демо: demo@forma.test / demo123</p></form>`;
V.register=()=>`<form class="fm" id="rg"><h1>Регистрация</h1>${fi('Имя','name','text','','required')}${fi('Email','email','email','','required')}${fi('Пароль (от 6 символов)','pass','password','','required minlength=6')}<button class="btn p">Создать аккаунт</button><p class="rt"><a href="#/login">Уже есть аккаунт</a></p></form>`;
V.forgot=()=>`<form class="fm" id="fg"><h1>Восстановление пароля</h1>${fi('Email','email','email','','required')}<button class="btn p">Отправить ссылку</button><p class="rt"><a href="#/login">Назад ко входу</a></p></form>`;
// admin: управление товарами
let ED={id:0,imgs:[]};
function drawImgs(){const b=$('#pimgs');if(!b)return;b.innerHTML=ED.imgs.length?ED.imgs.map((s,i)=>`<div class="pim"><img src="${esc(s)}" alt=""><button type="button" data-act="imgrm" data-i="${i}" aria-label="Убрать фото">✕</button></div>`).join(''):'<p class="rt" style="margin:0">Своё фото не задано — показывается значок категории.</p>'}
function shrink(file){return new Promise((res,rej)=>{const r=new FileReader();r.onerror=rej;r.onload=()=>{const im=new Image();im.onerror=rej;im.onload=()=>{const k=Math.min(1,800/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',.82))};im.src=r.result};r.readAsDataURL(file)})}
async function addFiles(t){const fs=[...t.files];t.value='';for(const fl of fs){if(ED.imgs.length>=3){toast('Максимум 3 изображения',1);break}try{ED.imgs.push(await shrink(fl))}catch(e){toast('Не удалось прочитать файл: '+fl.name,1)}}drawImgs()}
V.admin=(a,id)=>{
if(a==='new'||a==='edit'){const p=a==='edit'?ga(id):null;if(a==='edit'&&!p)return empty('⚠️','Товар не найден','','#/admin','К списку товаров');
ED={id:p?p.id:0,imgs:p?[...(p.imgs||[])]:[]};setTimeout(drawImgs,0);
const v=p||{cat:'protein',name:'',brand:'',price:'',old:'',stock:10,form:'Порошок',mass:'',serv:1,flavor:'Без вкуса',protein:0,rating:0,rev:0,desc:'',hid:0};
const dl=(i,a)=>`<datalist id="${i}">${[...new Set(a)].map(x=>`<option value="${esc(x)}">`).join('')}</datalist>`;
return`<nav class="rt" style="margin-top:14px"><a href="#/admin">← К списку товаров</a></nav><form class="fm wide" id="pe"><h1>${p?'Редактирование товара':'Новый товар'}</h1>
${fi('Название','name','text',v.name,'required')}${fi('Бренд','brand','text',v.brand,'list="dlb"')}
<label>Категория<select name="cat">${Object.entries(CATS).map(([k,c])=>`<option value="${k}" ${v.cat===k?'selected':''}>${c[0]}</option>`).join('')}</select></label>${fi('Форма выпуска','form','text',v.form,'list="dlf"')}
${fi('Цена, ₽','price','number',v.price,'required min="0" step="1"')}${fi('Старая цена, ₽ (0 — без скидки)','old','number',v.old||0,'min="0" step="1"')}
${fi('Остаток на складе, шт. (0 — нет в наличии)','stock','number',v.stock,'required min="0" step="1"')}${fi('Масса / объём (например 900 г)','mass','text',v.mass)}
${fi('Количество порций','serv','number',v.serv,'min="1" step="1"')}${fi('Вкус','flavor','text',v.flavor)}
${fi('Белок на порцию, г','protein','number',v.protein,'min="0" step="1"')}${fi('Рейтинг (0–5)','rating','number',v.rating,'min="0" max="5" step="0.1"')}
${fi('Количество отзывов','rev','number',v.rev,'min="0" step="1"')}<span></span>
<label class="full">Описание<textarea name="desc" rows="5">${esc(v.desc)}</textarea></label>
<div class="full"><b>Изображения</b> <span class="rt">— до 3 штук, первое будет главным</span><div id="pimgs" class="pims"></div>
<div class="prow"><label class="btn sm" style="cursor:pointer;display:inline-flex"><span>📁 Загрузить с компьютера</span><input type="file" id="pfile" accept="image/*" multiple hidden></label><input id="pu" placeholder="или путь / ссылка, например img/whey.jpg"><button type="button" class="btn sm" data-act="imgurl">Добавить</button></div></div>
<label class="full"><span><input type="checkbox" name="show" style="width:auto" ${v.hid?'':'checked'}> Показывать товар в каталоге</span></label>
<div class="full" style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn p">${p?'Сохранить изменения':'Добавить товар'}</button><a class="btn" href="#/admin">Отмена</a></div>
${dl('dlb',P.map(x=>x.brand))}${dl('dlf',P.map(x=>x.form))}</form>`}
const rows=P.map(p=>`<tr data-s="${esc((p.name+' '+p.brand+' '+CATS[p.cat][0]).toLowerCase())}"><td>${pic(p)}</td><td><b>${p.name}</b><br><span class="rt">${p.brand} · ${CATS[p.cat][0]}</span></td><td>${rub(p.price)}</td><td>${p.stock}</td><td><span class="st ${p.hid?'off':'on'}">${p.hid?'Скрыт':'В каталоге'}</span></td><td><div class="acts"><a class="btn sm" href="#/admin/edit/${p.id}">✎ Изменить</a><button class="btn sm" data-act="ahide" data-id="${p.id}">${p.hid?'＋ Вернуть в каталог':'− Убрать из каталога'}</button><button class="btn sm" data-act="adel" data-id="${p.id}">🗑 Удалить</button></div></td></tr>`).join('');
return`<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-top:20px"><h1>Управление товарами</h1><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn p" href="#/admin/new">＋ Добавить товар</a><button class="btn" data-act="areset">↺ Сбросить к исходному</button></div></div>
<p class="rt">Всего: ${P.length} · в каталоге: ${vis().length}. Изменения сохраняются в этом браузере и не видны на других устройствах.</p>
<div class="tb"><input id="aq" placeholder="Поиск по списку товаров" aria-label="Поиск по списку"></div>
<div class="ov"><table class="at"><tr><th></th><th>Товар</th><th>Цена</th><th>Остаток</th><th>Статус</th><th></th></tr>${rows}</table></div>`};
// router
function render(){const [h,qs]=(location.hash||'#/').slice(2).split('?');const [pg,arg,arg2]=h.split('/');const q=new URLSearchParams(qs||'');const prot=['account','checkout','success'];let v;window.scrollTo(0,0);
try{if(prot.includes(pg)&&!S.me){S.next=location.hash;toast('Войдите, чтобы продолжить',1);location.hash='#/login';return}
if((pg==='login'||pg==='register')&&S.me){location.hash='#/account';return}
const m={'':V.home,catalog:V.catalog,product:V.product,favorites:V.favorites,compare:V.compare,cart:V.cart,checkout:V.checkout,success:V.success,account:V.account,login:V.login,register:V.register,'forgot-password':V.forgot,admin:V.admin}[pg];
document.title='FORMA — спортивное питание и добавки';v=m?(pg==='admin'?V.admin(arg,arg2):m(pg==='product'||pg==='success'?arg:q)):empty('⚠️','Страница не найдена','Проверьте адрес','#/','На главную');
$('#app').innerHTML=v;if(pg==='catalog')V.after_catalog()}catch(e){$('#app').innerHTML=empty('⚠️','Что-то пошло не так','Попробуйте обновить страницу','#/','На главную')}badges()}
function refresh(){const y=window.scrollY;badges();if(($('#fp')))grid();else{render();window.scrollTo(0,y)}if($('#grid'))grid()}
function toggle(a,id,msgOn,msgOff){const i=a.indexOf(id);i<0?(a.push(id),toast(msgOn)):(a.splice(i,1),toast(msgOff));save()}
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(!b){if(!e.target.closest('.sw'))$('#dd').style.display='none';return}const a=b.dataset.act,id=+b.dataset.id,p=gp(id);
if(a==='fav'){toggle(S.fav,id,'Товар добавлен в избранное','Товар удалён из избранного');refresh()}
else if(a==='cmp'){if(!S.cmp.includes(id)){if(S.cmp.length&&gp(S.cmp[0]).cat!==p.cat){toast('Сравнивать можно товары одной категории',1);return}if(S.cmp.length>=4){toast('Максимум 4 товара',1);return}}toggle(S.cmp,id,'Товар добавлен к сравнению','Товар удалён из сравнения');refresh()}
else if(a==='cart'||a==='buy'){const q=b.dataset.q?+$('#pq').textContent:b.dataset.cq?(PQ[id]||1):1;S.cart[id]=Math.min(p.stock,(S.cart[id]||0)+q);delete PQ[id];save();toast('Товар добавлен в корзину');if(a==='buy')location.hash='#/cart';else refresh()}
else if(a==='inc'){S.cart[id]=Math.min(p.stock,S.cart[id]+1);save();render()}else if(a==='dec'){S.cart[id]>1?S.cart[id]--:delete S.cart[id];save();render()}
else if(a==='rm'){delete S.cart[id];save();toast('Товар удалён из корзины');render()}
else if(a==='pq'){const s=$('#pq');s.textContent=Math.max(1,+s.textContent+ +b.dataset.d)}
else if(a==='thumb'){$('#gal').innerHTML=pic(p,+b.dataset.i);document.querySelectorAll('.thumbs>div').forEach(d=>d.firstChild.classList.toggle('on',d===b))}
else if(a==='clrcmp'){S.cmp=[];save();render()}
else if(a==='promo'){const v=$('#pc').value.trim().toUpperCase();if(v==='FIT10'){S.promo=v;toast('Промокод применён: −10%')}else{S.promo='';toast(v?'Неверный промокод':'Промокод сброшен',!!v)}save();render()}
else if(a==='reset'){f=F0();$('#fp').innerHTML=panel();$('#cq').value='';$('#so').value='pop';grid()}
else if(a==='fopen')$('#fp').classList.add('open');else if(a==='fclose')$('#fp').classList.remove('open');
else if(a==='ahide'){const q=ga(id);if(q){q.hid=q.hid?0:1;purge();lists();save();saveP();toast(q.hid?'Товар убран из каталога':'Товар возвращён в каталог');refresh()}}
else if(a==='adel'){const q=ga(id);if(q&&confirm('Удалить товар «'+q.name+'» полностью? Это действие нельзя отменить.')){P.splice(P.indexOf(q),1);purge();lists();save();saveP();toast('Товар удалён');refresh()}}
else if(a==='areset'){if(confirm('Вернуть каталог к исходному состоянию? Все ваши изменения товаров будут потеряны.')){try{localStorage.removeItem('fm_products')}catch(e){}P=JSON.parse(JSON.stringify(DEF));purge();lists();save();toast('Каталог сброшен');refresh()}}
else if(a==='imgrm'){ED.imgs.splice(+b.dataset.i,1);drawImgs()}
else if(a==='imgurl'){const i=$('#pu'),v=i.value.trim();if(!v)return;if(ED.imgs.length>=3)return toast('Максимум 3 изображения',1);ED.imgs.push(v);i.value='';drawImgs()}
else if(a==='crm'){delete S.cart[id];delete PQ[id];save();toast('Товар удалён из корзины');refresh()}
else if(a==='logout'){S.me=null;save();toast('Вы вышли')}});
document.addEventListener('input',e=>{const t=e.target;if(t.id==='hs'){const q=t.value.trim().toLowerCase(),d=$('#dd');if(!q){d.style.display='none';return}const r=vis().filter(p=>(p.name+' '+p.brand+' '+CATS[p.cat][0]).toLowerCase().includes(q)).slice(0,5);d.innerHTML=r.length?r.map(p=>`<a href="#/product/${p.id}" data-close>${pic(p)}<span>${p.name}<br><small class="rt">${p.brand} · ${rub(p.price)}</small></span></a>`).join('')+`<a href="#/catalog?q=${encodeURIComponent(q)}"><b>Все результаты →</b></a>`:'<div style="padding:14px" class="rt">Ничего не найдено</div>';d.style.display='block'}
else if(t.id==='aq'){const q=t.value.trim().toLowerCase();document.querySelectorAll('.at tr[data-s]').forEach(r=>r.style.display=r.dataset.s.includes(q)?'':'none')}else if(t.id==='cq'){f.q=t.value;grid()}else if(t.dataset.f==='rng'){$('#fp [data-f=max]').value=t.value;readF();grid()}});
document.addEventListener('change',e=>{const t=e.target;if(t.id==='pfile'){addFiles(t)}else if(t.classList.contains('cq')){const id=+t.dataset.id,p=gp(id);if(!p)return;const v=Math.min(p.stock,Math.max(1,Math.round(+t.value)||1));t.value=v;if(S.cart[id]){S.cart[id]=v;save();badges()}else PQ[id]=v}else if(t.id==='so'){f.sort=t.value;grid()}else if(t.dataset.f){readF();grid()}});
$('#dd').addEventListener('click',()=>{$('#dd').style.display='none';$('#hs').value=''});
$('#hs').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.value.trim()){location.hash='#/catalog?q='+encodeURIComponent(e.target.value.trim());$('#dd').style.display='none'}});
document.addEventListener('submit',e=>{e.preventDefault();const id=e.target.id,d=Object.fromEntries(new FormData(e.target));
if(id==='lg'){const u=S.users.find(u=>u.email===d.email.toLowerCase()&&u.pass===d.pass);if(!u)return toast('Неверный email или пароль',1);S.me=u.email;save();toast('Добро пожаловать, '+u.name);const n=S.next;S.next=null;location.hash=n||'#/account'}
else if(id==='rg'){if(S.users.some(u=>u.email===d.email.toLowerCase()))return toast('Email уже зарегистрирован',1);S.users.push({name:d.name,email:d.email.toLowerCase(),phone:'',pass:d.pass,orders:[],notif:true});S.me=d.email.toLowerCase();save();toast('Аккаунт создан');location.hash='#/account'}
else if(id==='fg'){toast('Если аккаунт существует, ссылка отправлена (демо)');location.hash='#/login'}
else if(id==='pf'){const u=user();u.name=d.name;u.phone=d.phone;save();toast('Профиль сохранён')}
else if(id==='sf'){const u=user();u.notif=!!d.notif;S.theme=d.theme;save();badges();toast('Настройки сохранены')}
else if(id==='pe'){const cl=s=>String(s||'').replace(/[<>]/g,'').replace(/"/g,"'").trim(),n=x=>Math.max(0,Math.round(+x)||0);
const nm=cl(d.name);if(!nm)return toast('Укажите название',1);const ex=ED.id?ga(ED.id):null,cat=CATS[d.cat]?d.cat:'protein';
const o=Object.assign(ex||{id:Math.max(0,...P.map(p=>p.id))+1},{name:nm,brand:cl(d.brand)||'Без бренда',cat,price:n(d.price),old:n(d.old),stock:n(d.stock),form:cl(d.form)||'—',mass:cl(d.mass)||'—',serv:Math.max(1,n(d.serv)),flavor:cl(d.flavor)||'—',protein:n(d.protein),rating:Math.min(5,Math.max(0,+d.rating||0)),rev:n(d.rev),hid:d.show?0:1,imgs:ED.imgs.slice(0,3)});
if(o.old<=o.price)o.old=0;o.disc=o.old?Math.round(100-o.price/o.old*100):0;o.hue=CATS[cat][2];o.emoji=CATS[cat][1];
o.desc=cl(d.desc)||`${o.name} от бренда ${o.brand} — продукт категории «${CATS[cat][0]}». Информация носит справочный характер.`;
if(!ex)P.push(o);purge();lists();save();saveP();toast(ex?'Изменения сохранены':'Товар добавлен');location.hash='#/admin'}
else if(id==='co'){const c=calc(),u=user(),n='FM-'+Date.now().toString().slice(-7);u.orders.unshift({id:n,ts:Date.now(),s0:0,total:c.tot+c.ship,info:d,items:c.it.map(x=>({n:x.p.name,q:x.q,p:x.p.price}))});S.cart={};S.promo='';save();location.hash='#/success/'+n}});
// seed demo orders
(()=>{const u=S.users[0];if(u&&u.email==='demo@forma.test'&&!u.orders.length&&!LS('seeded',0)){u.orders=[{id:'FM-1000231',ts:Date.now()-864e5*9,s0:4,total:5280,items:[{n:DEF[0].name,q:1,p:DEF[0].price},{n:DEF[9].name,q:1,p:DEF[9].price}]},{id:'FM-1000377',ts:Date.now()-864e5*2,s0:2,total:2290,items:[{n:DEF[14].name,q:1,p:DEF[14].price}]}];SV('seeded',1);save()}})();
purge();save();addEventListener('hashchange',render);render();
