import { redirect } from "next/navigation";

/**
 * The supplied FORMA storefront is served as a static interactive demo (public/forma.html + forma.css + forma.js).
 * Its internal pages use hash-based navigation, so the entire experience works
 * from the same public URL and can be hosted on Vercel as part of this project.
 */
export default async function Page() {
  redirect("/forma.html");
}
