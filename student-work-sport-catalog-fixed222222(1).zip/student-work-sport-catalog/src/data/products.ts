export type Product = {
  id: number; name: string; brand: string; category: string; price: number; oldPrice?: number;
  weight: string; servings: number; form: string; flavor: string; rating: number; reviews: number;
  inStock: boolean; protein: number; description: string; color: string; isNew?: boolean;
  composition: string;
};

const seed: Array<Omit<Product, "id" | "rating" | "reviews" | "inStock" | "composition">> = [
  {name:"Whey Protein 80",brand:"Forge Nutrition",category:"Протеин",price:3290,oldPrice:3790,weight:"900 г",servings:30,form:"Порошок",flavor:"Ваниль",protein:24,description:"Сывороточный белковый продукт для повседневного рациона.",color:"blue"},
  {name:"Pure Creatine",brand:"Core Lab",category:"Креатин",price:1490,weight:"300 г",servings:60,form:"Порошок",flavor:"Без вкуса",protein:0,description:"Креатин моногидрат без добавленных ароматизаторов.",color:"orange"},
  {name:"Daily Multi",brand:"North Peak",category:"Витамины и минералы",price:990,weight:"60 таблеток",servings:60,form:"Таблетки",flavor:"Без вкуса",protein:0,description:"Витаминно-минеральный комплекс в таблетках.",color:"purple"},
  {name:"Pulse Pre-Workout",brand:"Forge Nutrition",category:"Предтренировочные комплексы",price:1790,oldPrice:1990,weight:"250 г",servings:25,form:"Порошок",flavor:"Ягодный микс",protein:0,description:"Порошковый предтренировочный продукт с ягодным вкусом.",color:"red"},
  {name:"Hydra Electrolytes",brand:"Hydra Works",category:"Электролиты",price:1190,weight:"180 г",servings:30,form:"Порошок",flavor:"Лимон",protein:0,description:"Смесь электролитов для приготовления напитка.",color:"green"},
  {name:"Protein Bar 12",brand:"Fuel Square",category:"Батончики и снеки",price:160,weight:"60 г",servings:1,form:"Батончик",flavor:"Шоколад",protein:12,description:"Протеиновый батончик в индивидуальной упаковке.",color:"pink"},
  {name:"Plant Protein",brand:"Core Lab",category:"Протеин",price:2790,weight:"750 г",servings:25,form:"Порошок",flavor:"Какао",protein:21,description:"Растительный белковый продукт с какао.",color:"green"},
  {name:"Casein Night",brand:"North Peak",category:"Протеин",price:3490,weight:"900 г",servings:30,form:"Порошок",flavor:"Клубника",protein:23,description:"Казеиновый белковый продукт с клубничным вкусом.",color:"pink"},
  {name:"Creatine Micro",brand:"Forge Nutrition",category:"Креатин",price:1890,weight:"500 г",servings:100,form:"Порошок",flavor:"Без вкуса",protein:0,description:"Мелкодисперсный креатин моногидрат.",color:"orange",isNew:true},
  {name:"Omega Balance",brand:"North Peak",category:"Витамины и минералы",price:1290,weight:"90 капсул",servings:45,form:"Капсулы",flavor:"Без вкуса",protein:0,description:"Капсулы с рыбьим жиром; состав указан для демонстрации.",color:"blue"},
  {name:"Magnesium Plus",brand:"Core Lab",category:"Витамины и минералы",price:890,weight:"60 капсул",servings:30,form:"Капсулы",flavor:"Без вкуса",protein:0,description:"Минеральный продукт в капсулах.",color:"purple"},
  {name:"BCAA Mix",brand:"Fuel Square",category:"Аминокислоты",price:1690,weight:"300 г",servings:30,form:"Порошок",flavor:"Арбуз",protein:0,description:"Порошковая смесь аминокислот с ароматом арбуза.",color:"pink"},
  {name:"EAA Complete",brand:"Forge Nutrition",category:"Аминокислоты",price:1990,weight:"270 г",servings:30,form:"Порошок",flavor:"Цитрус",protein:0,description:"Смесь незаменимых аминокислот.",color:"green"},
  {name:"Mass Builder",brand:"Core Lab",category:"Гейнеры",price:2790,weight:"1 кг",servings:10,form:"Порошок",flavor:"Шоколад",protein:18,description:"Углеводно-белковая смесь для приготовления напитка.",color:"orange"},
  {name:"Carb Drive",brand:"Fuel Square",category:"Батончики и снеки",price:790,weight:"500 г",servings:10,form:"Порошок",flavor:"Апельсин",protein:0,description:"Углеводный порошковый продукт.",color:"red"},
  {name:"Vitamin D3",brand:"North Peak",category:"Витамины и минералы",price:690,weight:"60 капсул",servings:60,form:"Капсулы",flavor:"Без вкуса",protein:0,description:"Продукт с витамином D3; дозировку проверяйте на упаковке.",color:"yellow"},
  {name:"Zinc Daily",brand:"Core Lab",category:"Витамины и минералы",price:590,weight:"60 таблеток",servings:60,form:"Таблетки",flavor:"Без вкуса",protein:0,description:"Минеральный продукт с цинком.",color:"blue"},
  {name:"Citrulline Flow",brand:"Forge Nutrition",category:"Предтренировочные комплексы",price:1490,weight:"200 г",servings:40,form:"Порошок",flavor:"Лайм",protein:0,description:"Порошковый продукт с цитруллином.",color:"green"},
  {name:"Beta-Alanine",brand:"Core Lab",category:"Аминокислоты",price:1090,weight:"200 г",servings:40,form:"Порошок",flavor:"Без вкуса",protein:0,description:"Порошковый продукт с бета-аланином.",color:"purple"},
  {name:"Shaker Steel",brand:"Forge Gear",category:"Аксессуары",price:1290,weight:"750 мл",servings:1,form:"Аксессуар",flavor:"Графит",protein:0,description:"Многоразовый шейкер для смешивания напитков.",color:"gray"},
  {name:"Shaker Lite",brand:"Forge Gear",category:"Аксессуары",price:590,weight:"600 мл",servings:1,form:"Аксессуар",flavor:"Лайм",protein:0,description:"Лёгкий пластиковый шейкер с крышкой.",color:"green"},
  {name:"Whey Protein 80 — Cocoa",brand:"Forge Nutrition",category:"Протеин",price:3390,weight:"900 г",servings:30,form:"Порошок",flavor:"Какао",protein:24,description:"Сывороточный белковый продукт со вкусом какао.",color:"brown"},
  {name:"Whey Protein 80 — Banana",brand:"Forge Nutrition",category:"Протеин",price:3290,weight:"900 г",servings:30,form:"Порошок",flavor:"Банан",protein:24,description:"Сывороточный белковый продукт со вкусом банана.",color:"yellow"},
  {name:"Creatine Caps",brand:"North Peak",category:"Креатин",price:1590,weight:"120 капсул",servings:30,form:"Капсулы",flavor:"Без вкуса",protein:0,description:"Креатин в капсулах.",color:"blue"},
  {name:"Hydra Electrolytes — Berry",brand:"Hydra Works",category:"Электролиты",price:1190,weight:"180 г",servings:30,form:"Порошок",flavor:"Лесные ягоды",protein:0,description:"Смесь электролитов с ягодным вкусом.",color:"pink"},
  {name:"Energy Gel",brand:"Fuel Square",category:"Батончики и снеки",price:180,weight:"40 г",servings:1,form:"Гель",flavor:"Апельсин",protein:0,description:"Порционный углеводный гель.",color:"orange"},
  {name:"Collagen Blend",brand:"North Peak",category:"Другое",price:1690,weight:"300 г",servings:30,form:"Порошок",flavor:"Нейтральный",protein:9,description:"Порошковый продукт на основе коллагеновых пептидов.",color:"purple"},
  {name:"L-Carnitine Drink",brand:"Hydra Works",category:"Другое",price:220,weight:"500 мл",servings:1,form:"Напиток",flavor:"Лимон",protein:0,description:"Готовый напиток; состав демонстрационный.",color:"yellow"},
  {name:"Training Straps",brand:"Forge Gear",category:"Аксессуары",price:790,weight:"1 пара",servings:1,form:"Аксессуар",flavor:"Чёрный",protein:0,description:"Текстильные лямки для тренировок.",color:"gray"},
  {name:"Vitamin C",brand:"Core Lab",category:"Витамины и минералы",price:650,weight:"90 таблеток",servings:90,form:"Таблетки",flavor:"Без вкуса",protein:0,description:"Продукт с витамином C.",color:"orange"},
];

export const products: Product[] = seed.map((p, i) => ({
  ...p, id: i + 1, rating: Number((4.1 + ((i * 7) % 9) / 10).toFixed(1)), reviews: 12 + ((i * 19) % 240),
  inStock: i !== 14 && i !== 26, composition: p.category === "Протеин" ? "Белковая смесь, ароматизатор, подсластитель (состав демонстрационный)." : "Состав демонстрационный. Перед покупкой изучите сведения на упаковке.",
}));

export const categories = ["Все товары", "Протеин", "Креатин", "Гейнеры", "Аминокислоты", "Витамины и минералы", "Предтренировочные комплексы", "Электролиты", "Батончики и снеки", "Аксессуары", "Другое"];
export const formatPrice = (value: number) => new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 }).format(value) + " ₽";
